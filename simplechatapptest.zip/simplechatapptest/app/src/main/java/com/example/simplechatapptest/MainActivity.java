package com.example.simplechatapptest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

   View view;
    TextView welcomeTextView;
    EditText messageEditText;
    Button sendButton;

    private Chatbot chatbot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chatbot = new Chatbot();

         EditText userInputEditText = findViewById(R.id.userInputEditText);
        final TextView chatTextView = findViewById(R.id.chatTextView);
        Button sendButton = findViewById(R.id.sendButton);

        sendButton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                String userInput = userInputEditText.getText().toString();
                String botResponse = chatbot.respondToUserInput(userInput);
                chatTextView.append("You: " + userInput + "\n");
                chatTextView.append("Bot: " + botResponse + "\n");
                userInputEditText.getText().clear();
            }
        });
    }
}
