package com.example.simplechatapptest;

public class Chatbot {
    public String respondToUserInput(String userInput) {
        if (userInput.contains("hi") || userInput.contains("hello")) {
            return "Hello! How can I help you?";
        } else if (userInput.contains("how are you")) {
            return "I'm just a chatbot, but thanks for asking!";
        } else if (userInput.contains("what is your name")) {
            return "I'm a chatbot. You can call me ChatBot.";
        } else {
            return "I'm sorry, I didn't understand that.";
        }
    }
}
